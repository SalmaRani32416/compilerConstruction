%{
#include <stdio.h>

int sym[26];

int yylex();
int yyerror(char *s);
%}

%token NUMBER VARIABLE
%left '+' '-'
%left '*' '/'

%%

input:
    | input line
    ;

line:
      '\n'
    | expr '\n'              { printf("= %d\n", $1); }
    | VARIABLE '=' expr '\n' { sym[$1 - 'a'] = $3; }
    ;

expr:
      NUMBER            { $$ = $1; }
    | VARIABLE          { $$ = sym[$1 - 'a']; }
    | expr '+' expr     { $$ = $1 + $3; }
    | expr '-' expr     { $$ = $1 - $3; }
    | expr '*' expr     { $$ = $1 * $3; }
    | expr '/' expr     { $$ = $1 / $3; }
    ;

%%

int main() {
    yyparse();
    return 0;
}

int yyerror(char *s) {
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}
